﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp_Hausarbeit;

//namespace WindowsFormsApp_Hausarbeit
//{
//    public class GenetischerAlgorithmus
//    {
//        // Parameter für den GA

//        public int PopulationSize { get; set; }
//        public int Generations { get; set; }
//        public double MutationRate { get; set; }
//        public double CrossoverRate { get; set; }
//        public double[,] data_YHL { get; set; }
//        public double bestFitness { get; set; }
//        public double[] bestIndividuum { get; set; }
//        public string bestWord { get; private set; }
//        public string TargetWord { get; private set; }

//        private string[] population;
//        //private Individual4Strings[] population; 
//        private double[] fitness;
//        private string[] oldPopulation;
//        private Random rnd = new Random();
//        private const string filler = "-";

//        public GenetischerAlgorithmus(string TargetWord, int PopulationSize,  double CrossoverRate, double MutationRate, int Generations, double[,] data_YHL)
//        {

//            this.TargetWord = TargetWord.ToUpper();
//            this.PopulationSize = PopulationSize;
//            this.Generations = Generations;
//            this.MutationRate = MutationRate;
//            this.CrossoverRate = CrossoverRate;
//            this.data_YHL = data_YHL;
//            population = new string[PopulationSize];
//            fitness = new double[PopulationSize];
//            oldPopulation = new string[PopulationSize];

//        }

//        #region Unterklassen

//        // Initialisierung der Population
//        private void CreatePopulation()
//        {
//            for (int i = 0; i < PopulationSize; i++)
//            {
//                population[i] = new CreateNewGenome(6, rnd).ToString();
//            }
//        }

//        // Wo TargetWord definieren?

//        // Zuweisen eines Fitness-Wertes zu jedem Individuum des Population
//        private void EvaluateFitness()
//        {
//            for (int i = 0; i < PopulationSize; i++)
//            {
//                fitness[i] = Levenshtein.LevenshteinDistance(TargetWord, population[i]);
//            }
//        }

//        // Selektion und Multi-Point Crossover von Individuen aus dem besseren Teil der Population ("besser" nach den Fitness-Werten) 
//        private void SelectionAndCrossover(string offspringParameter)
//        {
//            Array.Sort(fitness, population);                        // Population nach Fitness-Werten sortieren
//            bestFitness = fitness[0];
//            bestIndividuum = population[0].Split(' ').Select(gene => double.Parse(gene)).ToArray();
//            Array.Copy(population, oldPopulation, PopulationSize);  // Speichern der alten Population
            
//            for (int i = 1; i < PopulationSize; i++)                // 1. (und bestes) Individuum bleibt gleich, der Rest ist für die Nachkommen
//            {
//                int parent1 = rnd.Next(PopulationSize / 2);         // Entnehmen von 2 willkürlichen Eltern aus der besseren Hälfte der alten Population
//                int parent2 = rnd.Next(PopulationSize / 2);

//                if (rnd.NextDouble() < CrossoverRate)               // Entscheidung, ob Crossover eintritt
//                {
//                    StringBuilder childGenome = new StringBuilder();

//                    // Multi-Point Crossover: jedes Gen wird zufällig von einem der beiden Elternteile übernommen
//                    for (int j = 0; j < Math.Min(oldPopulation[parent1].Length, oldPopulation[parent2].Length); j++)
//                    {
//                        childGenome.Append(rnd.NextDouble() < 0.5 ? oldPopulation[parent1][j] : oldPopulation[parent2][j]);
//                    }
//                    population[i] = childGenome.ToString();
//                } 
//                // Kein Crossover und einer der beiden Elternteile (bzw. das Genom) wird in die neue Population gegeben
//                else
//                {
//                    population[i] = rnd.NextDouble() < 0.5 ? oldPopulation[parent1] : oldPopulation[parent2];
//                }
//            }
//        }

//        // Mutation einiger Nachkommen
//        private void Mutation()
//        {
//            for (int i = 1; i < PopulationSize; i++)            // Keine Mutation des 1. Individuums
//            {
//                if (rnd.NextDouble() < MutationRate)
//                {
//                    // Genom-String in einzelne Gene
//                    List<double> genome = population[i].Split(' ').Select(gene => double.Parse(gene)).ToList();

//                    switch (rnd.Next(3))                        // Zufällige Entscheidung, welche Mutation eintreten wird
//                    {
//                        case 0:                                 // Löschen eines zufälligen Gens
//                            if (genome.Count > 1) 
//                            {
//                                int deletepos = rnd.Next(genome.Count);
//                                genome.RemoveAt(deletepos);
//                            }
//                            break;

//                        case 1:                                 // Ändert zufälliges Gen (Zahl zwischen 0.1 und 5)
//                            int modifypos = rnd.Next(genome.Count);
//                            genome[modifypos] = Math.Round(rnd.NextDouble() * (5 - 0.1) + 0.1, 2); 
//                            break;

//                        case 2:                                 // Fügt zufälliges Gen hinzu (Zahl zwischen 0.1 und 5)
//                            double newGene = Math.Round(rnd.NextDouble() * (5 - 0.1) + 0.1, 2); 
//                            int insertpos = rnd.Next(genome.Count + 1);
//                            genome.Insert(insertpos, newGene);
//                            break;
//                    }
//                    population[i] = string.Join(" ", genome);   // Genom wird wieder zusammengefügt
//                }
//            }
//        }

//        #endregion 

//        // Ausführen des Genetischen Algorithmus 
//        /// <param name="Logging">Optional input: A delegate useful for logging purposes. Gets triggered after each generation.</param>
//        public void RunGA(Action<GenetischerAlgorithmus> Logging = null)
//        {
//            CreatePopulation();                             // Startpopulation erstellen
//            for (int gen = 0; gen < Generations; gen++)
//            {
//                EvaluateFitness();                          // Fitness bewerten
//                SelectionAndCrossover(string.Empty);        // Selektion der besten 50% und Crossover 
//                Mutation();                                 // Mutation und neue Population erstellen

//                if (Logging != null) Logging(this);
//            }
//        }

        //double FQS(double[] simulatedValues, double[] actualData)
        //{
        //    double fqs = 0;
        //    for (int i = 0; i < actualData.Length; i++)
        //    {
        //        fqs += Math.Pow(simulatedValues[i] - actualData[i], 2);
        //    }
        //    return fqs;
        //}

        //// Fitness-basierte Selektion
        //double[] SelectParent(List<double[]> population, double[] fitness)
        //{
        //    // Auswahl der Eltern basierend auf der Fitness 
        //    double totalFitness = fitness.Sum();
        //    double randomPosition = rnd.NextDouble() * totalFitness;
        //    double runningSum = 0;

        //    for (int i = 0; i < population.Count; i++)
        //    {
        //        runningSum += fitness[i];
        //        if (runningSum > randomPosition)
        //            return population[i];
        //    }
        //    return population[0];
        //}

        //// Selektion der besten 50% der Population
        //List<double[]> SelectUpperHalf(double[][] population, double[] fitness)
        //{
        //    // Sortiere die Population und die zugehörigen Fitnesswerte nach Fitness
        //    Array.Sort(fitness, population);

        //    // Nimm die besten 50% (erste Hälfte nach Sortierung)
        //    int cutoff = PopulationSize / 2;
        //    return population.Take(cutoff).ToList();
        //}

        //// Crossover zwischen zwei Elternteilen
        //double[] Crossover(double[] parent1, double[] parent2)
        //{
        //    double[] child = new double[parent1.Length];
        //    if (rnd.NextDouble() < CrossoverRate)
        //    {
        //        int crossoverPoint = rnd.Next(1, parent1.Length - 1); // Crossover-Punkt auswählen
        //        for (int i = 0; i < crossoverPoint; i++) child[i] = parent1[i];
        //        for (int i = crossoverPoint; i < parent2.Length; i++) child[i] = parent2[i];
        //    }
        //    else
        //    {
        //        // Falls kein Crossover, wähle zufällig einen Elternteil
        //        child = rnd.NextDouble() < 0.5 ? parent1 : parent2;
        //    }
        //    return child;
        //}



        //public void RunGA(Action<GenetischerAlgorithmus> Logging = null)
        //{
        //    // Messwerte einlesen


        //    // Start-Population erstellen
        //    List<double[]> population = InitializePopulation(populationSize);

        //    for (int generation = 0; generation < generations; generation++)
        //    {
        //        // Fitness für jedes Individuum berechnen 
        //        double[] fitness = new double[population.Count];
        //        for (int i = 0; i < population.Count; i++)
        //        {
        //            double[] simulatedValues = SimulateModel(population[i], initialValues, steps, dt);
        //            fitness[i] = CalculateFQS(simulatedValues, actualData);
        //        }

        //        // Selektion: Auswahl der besten 50% der Population
        //        double[][] populationArray = population.ToArray();
        //        population = SelectUpperHalf(populationArray, fitness);

        //        // Crossover und Mutation
        //        List<double[]> newPopulation = new List<double[]>();
        //        while (newPopulation.Count < populationSize)
        //        {
        //            // Wähle zwei Eltern zufällig aus den besten 50%
        //            double[] parent1 = population[random.Next(population.Count)];
        //            double[] parent2 = population[random.Next(population.Count)];

        //            // Erzeuge Nachkommen
        //            double[] child = Crossover(parent1, parent2);

        //            // Mutation anwenden
        //            Mutate(child);

        //            // Füge Nachkommen zur neuen Population hinzu
        //            newPopulation.Add(child);
        //        }

        //        // Population aktualisieren
        //        population = newPopulation;

        //        // Ausgabe der besten Fitness dieser Generation
        //        double bestFitness = fitness.Min();
        //        textBox8.Text = bestFitness.ToString();
        //    }
        //}

//    }
//}
